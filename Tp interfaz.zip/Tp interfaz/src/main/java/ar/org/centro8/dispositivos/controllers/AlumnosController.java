package ar.org.centro8.dispositivos.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.dispositivos.entities.Alumno;
import ar.org.centro8.dispositivos.entities.Curso;
import ar.org.centro8.dispositivos.repositories.AlumnosRepository;
import ar.org.centro8.dispositivos.repositories.CursosRepository;

@Controller
public class AlumnosController {
    private String mensaje = "Ingrese los datos del Alumno:";
    @Autowired
    AlumnosRepository ar;

    @Autowired
    CursosRepository cr;

    @GetMapping("/alumnos")
    public String getAlumnos(@RequestParam(name = "buscarAlumno", required = false, defaultValue = "") String buscar,
            Model model) {
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("alumnos", new Alumno());
        model.addAttribute("lista",
                ((List<Alumno>) ar.findAll()).stream()
                        .filter(a -> a.getNombre().toLowerCase().contains(buscar.toLowerCase()) ||
                                a.getApellido().toLowerCase().contains(buscar.toLowerCase()))
                        .toList());
        model.addAttribute("cursos", ((List<Curso>) cr.findAll()));
        return "alumnos";
    }

    @PostMapping("/saveAlumno")
    public String guardarAlumno(@ModelAttribute Alumno alumno, @RequestParam("idCurso") int idCurso) {
        Curso curso = cr.findById(idCurso).orElse(null);
        alumno.setCurso(curso);
        ar.save(alumno);

        if (alumno.getId() >= 0) {
            mensaje = "Se guardó el Alumno con el ID: " + alumno.getId();
        } else {
            mensaje = "No se pudo guardar el Alumno";
        }
        return "redirect:alumnos";
    }

}
