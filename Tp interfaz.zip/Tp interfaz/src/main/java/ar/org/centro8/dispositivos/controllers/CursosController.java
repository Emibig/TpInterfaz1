package ar.org.centro8.dispositivos.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.dispositivos.entities.Curso;
import ar.org.centro8.dispositivos.repositories.CursosRepository;

@Controller
public class CursosController {

    private String mensaje = "Ingrese los datos del curso:";
    @Autowired
    CursosRepository cr;

    @GetMapping("/index")
    public String getIndex(Model model) {

        return "index";
    }

    @GetMapping("/cursos")
    public String getCursos(
            @RequestParam(name = "buscarCurso", required = false, defaultValue = "") String buscar,
            Model model) {
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("cursos", new Curso());
        model.addAttribute("lista",
                ((List<Curso>) cr.findAll()).stream()
                        .filter(a -> a.getProfesor().toLowerCase().contains(buscar.toLowerCase()) ||
                                a.getTitulo().toLowerCase().contains(buscar.toLowerCase()))
                        .toList());
        return "cursos";
    }

    @PostMapping("/saveCurso")
    public String guardarCurso(@ModelAttribute Curso curso) {
        cr.save(curso);
        if (curso.getId() >= 0) {
            mensaje = "Se guardo el Curso con el ID: " + curso.getId();
        } else {
            mensaje = "No se pudo Guardar el Curso";
        }
        return "redirect:cursos";

    }

}
