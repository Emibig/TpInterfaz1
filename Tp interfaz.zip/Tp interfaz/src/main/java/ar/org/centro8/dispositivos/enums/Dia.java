package ar.org.centro8.dispositivos.enums;

public enum Dia {
    LUNES,MARTES,MIERCOLES,JUEVES,VIERNES,SABADO
}
