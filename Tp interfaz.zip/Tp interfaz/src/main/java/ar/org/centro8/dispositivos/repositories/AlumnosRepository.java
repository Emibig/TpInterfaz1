package ar.org.centro8.dispositivos.repositories;


import org.springframework.data.repository.CrudRepository;

import ar.org.centro8.dispositivos.entities.Alumno;

public interface AlumnosRepository extends CrudRepository<Alumno,Integer> {
    
}